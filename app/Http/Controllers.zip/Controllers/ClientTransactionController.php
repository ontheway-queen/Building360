<?php

namespace App\Http\Controllers;

use App\Models\ClientTransection;
use Illuminate\Http\Request;

class ClientTransectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ClientTransection  $clientTransection
     * @return \Illuminate\Http\Response
     */
    public function show(ClientTransection $clientTransection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ClientTransection  $clientTransection
     * @return \Illuminate\Http\Response
     */
    public function edit(ClientTransection $clientTransection)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ClientTransection  $clientTransection
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ClientTransection $clientTransection)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ClientTransection  $clientTransection
     * @return \Illuminate\Http\Response
     */
    public function destroy(ClientTransection $clientTransection)
    {
        //
    }
}
